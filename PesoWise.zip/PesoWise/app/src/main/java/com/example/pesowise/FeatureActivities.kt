package com.example.pesowise

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class TransactionListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val text = TextView(this).apply {
            text = "Transactions Screen"
            textSize = 24f
        }

        setContentView(text)
    }
}