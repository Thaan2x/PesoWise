package com.example.pesowise

import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.time.YearMonth
import java.util.Locale

class BudgetActivity : AppCompatActivity() {

    private var monthlyBudget = 0.0
    private var totalExpenses = 0.0

    private lateinit var txtBudget: TextView
    private lateinit var txtSpent: TextView
    private lateinit var txtRemaining: TextView
    private lateinit var txtPercentage: TextView
    private lateinit var budgetProgress: ProgressBar

    private val preferences by lazy {
        getSharedPreferences("PesoWiseBudget", MODE_PRIVATE)
    }

    private val budgetKey: String
        get() = "monthly_budget_${YearMonth.now()}"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_budget)

        txtBudget = findViewById(R.id.txtBudget)
        txtSpent = findViewById(R.id.txtSpent)
        txtRemaining = findViewById(R.id.txtRemaining)
        txtPercentage = findViewById(R.id.txtPercentage)
        budgetProgress = findViewById(R.id.budgetProgress)

        loadBudget()
        updateBudgetDisplay()

        findViewById<Button>(R.id.btnSetBudget)
            .setOnClickListener {
                showBudgetDialog()
            }

        findViewById<Button>(R.id.btnBack)
            .setOnClickListener {
                finish()
            }
    }

    override fun onResume() {
        super.onResume()
        loadBudget()
        updateBudgetDisplay()
    }

    private fun loadBudget() {
        monthlyBudget = preferences.getFloat(
            budgetKey, 0f
        ).toDouble()

        // Temporary until Supabase transactions are connected
        totalExpenses = 0.0
    }

    private fun showBudgetDialog() {

        val input = EditText(this).apply {
            hint = "Enter monthly budget"
            inputType = InputType.TYPE_CLASS_NUMBER or
                    InputType.TYPE_NUMBER_FLAG_DECIMAL
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Set Monthly Budget")
            .setMessage("Enter your monthly budget in PHP.")
            .setView(input)
            .setPositiveButton("Save", null)
            .setNegativeButton("Cancel", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener {

                    val amount = input.text.toString()
                        .toDoubleOrNull()

                    if (amount == null ||
                        !amount.isFinite() ||
                        amount <= 0.0 ||
                        amount > Float.MAX_VALUE
                    ) {
                        input.error = "Enter a valid budget amount"
                    } else {

                        monthlyBudget = amount

                        preferences.edit()
                            .putFloat(budgetKey, amount.toFloat())
                            .apply()

                        updateBudgetDisplay()

                        Toast.makeText(
                            this,
                            "Monthly budget saved!",
                            Toast.LENGTH_SHORT
                        ).show()

                        dialog.dismiss()
                    }
                }
        }

        dialog.show()
    }

    private fun updateBudgetDisplay() {

        val remaining = monthlyBudget - totalExpenses

        val percentage = if (monthlyBudget > 0) {
            ((totalExpenses / monthlyBudget) * 100)
                .toInt()
                .coerceIn(0, 100)
        } else {
            0
        }

        txtBudget.text = formatPeso(monthlyBudget)

        txtSpent.text =
            "Total Spent: ${formatPeso(totalExpenses)}"

        txtRemaining.text =
            "Remaining: ${formatPeso(remaining)}"

        txtPercentage.text = "$percentage% Used"

        budgetProgress.progress = percentage
    }

    private fun formatPeso(amount: Double): String {
        return String.format(
            Locale.US,
            "₱%,.2f",
            amount
        )
    }
}